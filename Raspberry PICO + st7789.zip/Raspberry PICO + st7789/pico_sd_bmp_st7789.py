import machine
from machine import Pin,SPI
import st7789 as st7789
from st7789 import color565
from fonts import vga2_8x8 as font1
from fonts import vga1_16x32 as font2
import sdcard
import uos
from bmp_reader import BMPReader
from micropython import const
import os
import time

spi0_sck=18
spi0_mosi=19
spi0_miso=8     #not use
st7789_res = 20
st7789_dc  = 17
disp_width = 240
disp_height = 240

print(os.uname())
CENTER_Y = int(disp_width/2)
CENTER_X = int(disp_height/2)

spi0 = machine.SPI(0,62500000,sck=Pin(18),mosi=Pin(19),polarity=1,phase=0)
print(spi0)
display = st7789.ST7789(spi0, disp_width, disp_width,
                          reset=machine.Pin(st7789_res, machine.Pin.OUT),
                          dc=machine.Pin(st7789_dc, machine.Pin.OUT),
                          rotation=0)
#display.erase()
#display.set_pos(0,0)

# Assign chip select (CS) pin (and start it high)
cs = machine.Pin(9, machine.Pin.OUT)

# Intialize SPI peripheral (start with 1 MHz)
spi = machine.SPI(1,
                  baudrate=10000000,
                  polarity=0,
                  phase=0,
                  bits=8,
                  firstbit=machine.SPI.MSB,
                  sck=machine.Pin(10),
                  mosi=machine.Pin(11),
                  miso=machine.Pin(12))

# Initialize SD card
sd = sdcard.SDCard(spi, cs)

# Mount filesystem
vfs = uos.VfsFat(sd)
uos.mount(vfs, "/sd")

def Draw_BMP(strFile):
    def lebytes_to_int(bytes):
        n = 0x00
        while len(bytes) > 0:
            n <<= 8
            n |= bytes.pop()
        return int(n)
    f = open(strFile, 'rb')
    img_bytes = list(bytearray(f.read(54)))
    if img_bytes:
        # Leo el archivo BMP
        assert img_bytes[0:2] == [66, 77], "Not a valid BMP file"
        assert lebytes_to_int(img_bytes[30:34]) == 0, \
            "Compression is not supported"
        assert lebytes_to_int(img_bytes[28:30]) == 24, \
            "Only 24-bit colour depth is supported"

        start_pos = lebytes_to_int(img_bytes[10:14])
        end_pos = start_pos + lebytes_to_int(img_bytes[34:38])

        width = lebytes_to_int(img_bytes[18:22])
        height = lebytes_to_int(img_bytes[22:26])
        contador = 0
        tamaño = (end_pos - start_pos) 
    while (contador < tamaño):
        #pixel_data = img_bytes[start_pos:end_pos]
        print(tamaño)
        for y in range(height):
            for x in range(width):
                contador = contador + 3
                img_bytes = list(bytearray(f.read(3)))
                r = img_bytes[0]
                g = img_bytes[1]
                b = img_bytes[2]
                colorArmado = color565(b, g, r)
                #print(colorArmado, r, g, b, "pos:",y, x)        
                display.pixel(x, y,colorArmado )       

#Leo el bmp desde el sd
Draw_BMP('/sd/Tiger240.bmp')

# pixel_bruto = img.get_array()
# 
# 
# print(img.height)
# print(img.width)
# dimension = img.height * img.width * 3
# print(dimension)
# i = 0
# for row in range(img.height):
#     for col in range(img.width):
#         # The Unicorn Hat arranges its pixels starting top-right and alternates
#         # back and forth with each row so we need to reverse the even rows
#         bitbuff = []
#         colores = pixel_bruto[i]
#         colorArmado = color565(colores[0],colores[1], colores[2])
#         print(colores, colores[0],colores[1],colores[2], "pos:",row, col)        
#         display.pixel(row, col, colorArmado )
#         i = i + 1
#         #pixels[i] = pixel_grid[row][col]
        
#blit(self, bitbuff, x, y, w, h):
#pixels.show()

